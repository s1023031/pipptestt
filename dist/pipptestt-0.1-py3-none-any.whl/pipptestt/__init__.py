class ani():
	def __init__(self):
  		self.name = "TEST"

def testpac():
	return 123

a = ani() 
print(a.name)
b = testpac()
print(b)