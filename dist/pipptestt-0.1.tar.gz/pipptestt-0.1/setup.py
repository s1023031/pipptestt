from setuptools import setup
setup(name='pipptestt',
      version='0.1',
      description='learning to use pip',
      url='https://github.com/s1023031/pipptestt.git',
      author='Aileene',
      author_email='doremonyun0120@gmail.com',
      license='MIT',
      packages=['pipptestt'],
      zip_safe=False)
